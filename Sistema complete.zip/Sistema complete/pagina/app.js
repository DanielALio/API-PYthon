const API = "http://127.0.0.1:8000";

async function listarLivros() {
    const lista = document.getElementById("lista");
    const mensagem = document.getElementById("mensagem");
    lista.innerHTML = "";

    try {
        const resposta = await fetch(API + "/livros");
        if (!resposta.ok) {
            throw new Error(`A API respondeu com status ${resposta.status}.`);
        }

        const livros = await resposta.json();
        if (!Array.isArray(livros)) {
            throw new Error("A resposta da API não é uma lista de livros.");
        }

        if (livros.length === 0) {
            const item = document.createElement("li");
            item.textContent = "Nenhum livro encontrado no banco de dados.";
            lista.appendChild(item);
            return;
        }

        for (const livro of livros) {
            const item = document.createElement("li");
            item.textContent = `${livro.id} - ${livro.titulo} - ${livro.autor} (${livro.ano})`;
            lista.appendChild(item);
        }
    } catch (erro) {
        const item = document.createElement("li");
        item.textContent = "Não foi possível carregar os livros.";
        lista.appendChild(item);
        if (mensagem) {
            mensagem.textContent = "Confira se a API está rodando no VS Code (python api.py) e tente Listar livros novamente.";
        }
        console.error("Erro ao listar livros:", erro);
    }
}

async function buscarLivro() {
    const codigo = document.getElementById("codigo").value;
    const resultado = document.getElementById("resultado");

    if (!codigo) {
        resultado.textContent = "Digite o código de um livro.";
        return;
    }

    try {
        const resposta = await fetch(API + "/livros/" + codigo);
        const livro = await resposta.json();

        if (!resposta.ok) {
            resultado.textContent = livro.detail || "Livro não encontrado.";
            return;
        }

        resultado.textContent = `${livro.titulo} - ${livro.autor} (${livro.ano})`;
    } catch (erro) {
        resultado.textContent = "Não foi possível acessar a API. Confira se ela está rodando.";
        console.error("Erro ao buscar livro:", erro);
    }
}

async function cadastrarLivro() {
    const campoTitulo = document.getElementById("titulo");
    const campoAutor = document.getElementById("autor");
    const campoAno = document.getElementById("ano");
    const mensagem = document.getElementById("mensagem");

    const novo = {
        titulo: campoTitulo.value.trim(),
        autor: campoAutor.value.trim(),
        ano: Number(campoAno.value),
    };

    try {
        const resposta = await fetch(API + "/livros", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(novo),
        });
        const livro = await resposta.json();

        if (!resposta.ok) {
            mensagem.textContent = livro.detail || "Não foi possível cadastrar o livro.";
            return;
        }

        mensagem.textContent = `Cadastrado: ${livro.titulo} (código ${livro.id})`;
        campoTitulo.value = "";
        campoAutor.value = "";
        campoAno.value = "";
        await listarLivros();
    } catch (erro) {
        mensagem.textContent = "Não foi possível acessar a API. Confira se ela está rodando.";
        console.error("Erro ao cadastrar livro:", erro);
    }
}

async function excluirLivro() {
    const codigo = document.getElementById("codigo-excluir").value;
    const mensagem = document.getElementById("mensagem-excluir");

    if (!codigo) {
        mensagem.textContent = "Digite o código de um livro.";
        return;
    }

    try {
        const resposta = await fetch(API + "/livros/" + codigo, {
            method: "DELETE",
        });

        // A resposta 204 não tem corpo; só leia JSON em caso de erro.
        if (!resposta.ok) {
            const erro = await resposta.json();
            mensagem.textContent = erro.detail || "Não foi possível excluir o livro.";
            return;
        }

        mensagem.textContent = `Excluído o livro de código ${codigo}.`;
        await listarLivros();
    } catch (erro) {
        mensagem.textContent = "Não foi possível acessar a API. Confira se ela está rodando.";
        console.error("Erro ao excluir livro:", erro);
    }
}

async function alterarLivro() {
    const codigo = document.getElementById("codigo-alterar").value;
    const campoTitulo = document.getElementById("novo-titulo");
    const campoAutor = document.getElementById("novo-autor");
    const campoAno = document.getElementById("novo-ano");
    const mensagem = document.getElementById("mensagem-alterar");

    if (!codigo) {
        mensagem.textContent = "Digite o código de um livro.";
        return;
    }

    const alterado = {
        titulo: campoTitulo.value.trim(),
        autor: campoAutor.value.trim(),
        ano: Number(campoAno.value),
    };

    try {
        const resposta = await fetch(API + "/livros/" + codigo, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(alterado),
        });
        const livro = await resposta.json();

        if (!resposta.ok) {
            mensagem.textContent = livro.detail || "Não foi possível alterar o livro.";
            return;
        }

        mensagem.textContent = `Alterado: ${livro.titulo} (código ${livro.id})`;
        await listarLivros();
    } catch (erro) {
        mensagem.textContent = "Não foi possível acessar a API. Confira se ela está rodando.";
        console.error("Erro ao alterar livro:", erro);
    }
}

const botaoListar = document.getElementById("botao-listar");
botaoListar.addEventListener("click", listarLivros);
const botaoBuscar = document.getElementById("botao-buscar");
botaoBuscar.addEventListener("click", buscarLivro);
const botaoCadastrar = document.getElementById("botao-cadastrar");
botaoCadastrar.addEventListener("click", cadastrarLivro);

// Carrega os livros do banco assim que a página abre.
listarLivros();

const botaoExcluir = document.getElementById("botao-excluir");
botaoExcluir.addEventListener("click", excluirLivro);
const botaoAlterar = document.getElementById("botao-alterar");
botaoAlterar.addEventListener("click", alterarLivro);
