import tkinter as tk
from dominio.livro import Livro
from dominio.usuario import Usuario
from dominio.emprestimo import Emprestimo
from dados.repositorio_livro import RepositorioLivro


def carregar_acervo():
    repositorio = RepositorioLivro()
    try:
        return repositorio.listar()
    finally:
        repositorio.fechar()


acervo = carregar_acervo()
emprestimos = []
usuario = Usuario("Eric", "695487")

janela = tk.Tk()
janela.title("Biblioteca")
janela.geometry("750x600")

tk.Label(janela, text="Acervo", font=("Arial", 14)).pack(pady=6)
quadro_lista = tk.Frame(janela)
quadro_lista.pack(padx=10)
lista = tk.Listbox(quadro_lista, width=72, height=10, yscrollcommand=None)
barra = tk.Scrollbar(quadro_lista, orient=tk.VERTICAL, command=lista.yview)
lista.configure(yscrollcommand=barra.set)
lista.pack(side=tk.LEFT)
barra.pack(side=tk.RIGHT, fill=tk.Y)

for livro in acervo:
    lista.insert(tk.END, str(livro))

campo_emprestimo = tk.Entry(janela, width=34)
campo_emprestimo.pack(pady=8)
resultado = tk.Label(janela, text="", fg="blue")


def emprestar():
    procurado = campo_emprestimo.get().strip()
    escolhido = next((livro for livro in acervo if livro.titulo.casefold() == procurado.casefold()), None)
    if escolhido is None:
        resultado.config(text="Livro não está no acervo.", fg="red")
        return
    emprestimo = Emprestimo(escolhido, usuario, "27/09/2026")
    emprestimos.append(emprestimo)
    resultado.config(text="Emprestado: " + str(emprestimo), fg="blue")


def devolver():
    if not emprestimos:
        resultado.config(text="Não há empréstimo.", fg="red")
        return
    emprestimo = next((item for item in reversed(emprestimos) if not item.entregue), None)
    if emprestimo is None:
        resultado.config(text="Não há empréstimo em aberto.", fg="red")
        return
    try:
        emprestimo.devolver()
        resultado.config(text="Devolvido: " + str(emprestimo), fg="blue")
    except ValueError as erro:
        resultado.config(text=str(erro), fg="red")


tk.Button(janela, text="Emprestar", command=emprestar).pack()
tk.Button(janela, text="Devolver", command=devolver).pack()
resultado.pack(pady=6)

tk.Label(janela, text="Cadastrar livro", font=("Arial", 12)).pack(pady=(10, 4))
formulario = tk.Frame(janela)
formulario.pack()
tk.Label(formulario, text="Título:").grid(row=1, column=0, sticky="e")
campo_titulo = tk.Entry(formulario, width=28)
campo_titulo.grid(row=1, column=1, pady=2)
tk.Label(formulario, text="Autor:").grid(row=2, column=0, sticky="e")
campo_autor = tk.Entry(formulario, width=28)
campo_autor.grid(row=2, column=1, pady=2)
tk.Label(formulario, text="Ano de publicação:").grid(row=3, column=0, sticky="e")
campo_ano = tk.Entry(formulario, width=28)
campo_ano.grid(row=3, column=1, pady=2)


def atualizar_lista():
    lista.delete(0, tk.END)
    for livro in acervo:
        lista.insert(tk.END, str(livro))


def cadastrar():
    titulo = campo_titulo.get().strip()
    autor = campo_autor.get().strip()
    ano_texto = campo_ano.get().strip()
    try:
        livro = Livro(titulo, autor, int(ano_texto))
        if any(item.titulo.casefold() == titulo.casefold() and item.autor.casefold() == autor.casefold() for item in acervo):
            resultado.config(text="Esse livro já está cadastrado.", fg="red")
            return
        repositorio = RepositorioLivro()
        try:
            repositorio.salvar(livro)
        finally:
            repositorio.fechar()
        acervo.append(livro)
        atualizar_lista()
        campo_titulo.delete(0, tk.END)
        campo_autor.delete(0, tk.END)
        campo_ano.delete(0, tk.END)
        resultado.config(text=f"Livro cadastrado: {titulo} / {autor} / {ano_texto}", fg="blue")
    except (ValueError, TypeError) as erro:
        resultado.config(text=f"Erro: {erro}", fg="red")


tk.Button(janela, text="Cadastrar", command=cadastrar).pack(pady=6)
janela.mainloop()
