import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from dominio.livro import Livro
from dados.repositorio_livro import RepositorioLivro

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def inicio():
    return {"mensagem": "API da biblioteca"}


def para_dict(livro):
    return {
        "id": livro.id,
        "titulo": livro.titulo,
        "autor": livro.autor,
        "ano": livro.ano,
    }


def para_livro(corpo):
    return Livro(corpo["titulo"], corpo["autor"], int(corpo["ano"]))


@app.get("/livros")
def listar_livros():
    repositorio = RepositorioLivro()
    try:
        livros = repositorio.listar()
        return [para_dict(livro) for livro in livros]
    finally:
        repositorio.fechar()


@app.get("/livros/{codigo}")
def buscar_livro(codigo: int):
    repositorio = RepositorioLivro()
    try:
        livro = repositorio.buscar_por_id(codigo)
    finally:
        repositorio.fechar()

    if livro is None:
        raise HTTPException(status_code=404, detail="Livro não encontrado")
    return para_dict(livro)


@app.post("/livros", status_code=201)
def cadastrar_livro(corpo: dict):
    try:
        livro = para_livro(corpo)
    except (KeyError, ValueError, TypeError) as erro:
        raise HTTPException(status_code=400, detail=str(erro))

    repositorio = RepositorioLivro()
    try:
        repositorio.salvar(livro)
        return para_dict(livro)
    finally:
        repositorio.fechar()


@app.put("/livros/{codigo}")
def atualizar_livro(codigo: int, corpo: dict):
    try:
        livro = para_livro(corpo)
    except (KeyError, ValueError, TypeError) as erro:
        raise HTTPException(status_code=400, detail=str(erro))

    repositorio = RepositorioLivro()
    try:
        if repositorio.buscar_por_id(codigo) is None:
            raise HTTPException(status_code=404, detail="Livro não encontrado")
        livro.id = codigo
        repositorio.atualizar(livro)
        return para_dict(livro)
    finally:
        repositorio.fechar()


@app.delete("/livros/{codigo}", status_code=204)
def excluir_livro(codigo: int):
    repositorio = RepositorioLivro()
    try:
        if repositorio.buscar_por_id(codigo) is None:
            raise HTTPException(status_code=404, detail="Livro não encontrado")
        repositorio.excluir(codigo)
    finally:
        repositorio.fechar()


if __name__ == "__main__":
    uvicorn.run(app)
