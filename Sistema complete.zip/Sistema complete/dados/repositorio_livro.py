import sqlite3
from pathlib import Path

from dominio.livro import Livro


class RepositorioLivro:

    def __init__(self):
        caminho_banco = Path(__file__).resolve().parents[1] / "biblioteca.db"
        self.conexao = sqlite3.connect(caminho_banco)
        self.cursor = self.conexao.cursor()
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS livro (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                autor TEXT,
                ano INTEGER
            )
        """)
        self.conexao.commit()

    @staticmethod
    def _livro_da_linha(linha):
        codigo, titulo, autor, ano = linha
        livro = Livro(titulo, autor, ano)
        livro.id = codigo
        return livro

    def listar(self):
        self.cursor.execute(
            "SELECT id, titulo, autor, ano FROM livro ORDER BY id"
        )
        return [self._livro_da_linha(linha) for linha in self.cursor.fetchall()]

    def buscar_por_id(self, codigo):
        self.cursor.execute(
            "SELECT id, titulo, autor, ano FROM livro WHERE id = ?", (codigo,)
        )
        linha = self.cursor.fetchone()
        return self._livro_da_linha(linha) if linha else None

    def salvar(self, livro):
        self.cursor.execute(
            "INSERT INTO livro (titulo, autor, ano) VALUES (?, ?, ?)",
            (livro.titulo, livro.autor, livro.ano),
        )
        livro.id = self.cursor.lastrowid
        self.conexao.commit()
        return livro

    def atualizar(self, livro):
        self.cursor.execute(
            "UPDATE livro SET titulo = ?, autor = ?, ano = ? WHERE id = ?",
            (livro.titulo, livro.autor, livro.ano, livro.id),
        )
        self.conexao.commit()
        return livro

    def excluir(self, codigo):
        self.cursor.execute("DELETE FROM livro WHERE id = ?", (codigo,))
        self.conexao.commit()

    def fechar(self):
        self.conexao.close()
