from pathlib import Path
import sqlite3

caminho_banco = Path(__file__).resolve().parent / "biblioteca.db"
conexao = sqlite3.connect(caminho_banco)
cursor = conexao.cursor()

cursor.execute("""
    CREATE TABLE IF NOT EXISTS livro (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titulo TEXT NOT NULL,
        autor TEXT,
        ano INTEGER
    )
""")

cursor.execute(
    """
    INSERT INTO livro (titulo, autor, ano)
    SELECT ?, ?, ?
    WHERE NOT EXISTS (
        SELECT 1 FROM livro
        WHERE lower(titulo) = lower(?) AND lower(autor) = lower(?)
    )
    """,
    ("O nome do vento", "Patrick Rothfuss", 2009, "O nome do vento", "Patrick Rothfuss"),
)

conexao.commit()
cursor.execute("SELECT id, titulo, autor, ano FROM livro ORDER BY id")
for codigo, titulo, autor, ano in cursor.fetchall():
    print(f"{codigo} - {titulo} - {autor} - {ano}")
conexao.close()
