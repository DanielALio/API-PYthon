
const API = "http://127.0.0.1:8000";

const app = Vue.createApp({
    data() {
        return {
            livros: [],
            codigo: "",
            resultado: "",
            titulo: "",
            autor: "",
            ano: "",
            mensagem: "",
            erroMensagem: false,
            editando: null,
        };
    },
    methods: {
        async listarLivros() {
            try {
                const resposta = await fetch(API + "/livros");
                const dados = await resposta.json();
                if (!resposta.ok) {
                    this.mensagem = dados.detail || "Não foi possível listar os livros.";
                    this.erroMensagem = true;
                    return;
                }
                this.livros = dados;
            } catch (erro) {
                this.mensagem = "Não foi possível acessar a API. Confira se ela está rodando.";
                this.erroMensagem = true;
                console.error("Erro ao listar livros:", erro);
            }
        },

        async buscarLivro() {
            this.resultado = "";
            if (!this.codigo) {
                this.resultado = "Digite o código de um livro.";
                return;
            }
            try {
                const resposta = await fetch(API + "/livros/" + this.codigo);
                const livro = await resposta.json();
                if (!resposta.ok) {
                    this.resultado = livro.detail || "Livro não encontrado";
                    return;
                }
                this.resultado = `${livro.titulo} - ${livro.autor} (${livro.ano})`;
            } catch (erro) {
                this.resultado = "Não foi possível acessar a API. Confira se ela está rodando.";
                console.error("Erro ao buscar livro:", erro);
            }
        },

        async cadastrarLivro() {
            this.mensagem = "";
            this.erroMensagem = false;
            const novo = {
                titulo: this.titulo.trim(),
                autor: this.autor.trim(),
                ano: Number(this.ano),
            };
            try {
                const resposta = await fetch(API + "/livros", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(novo),
                });
                const livro = await resposta.json();
                if (!resposta.ok) {
                    this.mensagem = livro.detail || "Não foi possível cadastrar o livro.";
                    this.erroMensagem = true;
                    return;
                }
                this.mensagem = `Cadastrado: ${livro.titulo} (código ${livro.id})`;
                // push altera o array observado pelo Vue, e a lista redesenha sozinha.
                this.livros.push(livro);
                this.titulo = "";
                this.autor = "";
                this.ano = "";
            } catch (erro) {
                this.mensagem = "Não foi possível acessar a API. Confira se ela está rodando.";
                this.erroMensagem = true;
                console.error("Erro ao cadastrar livro:", erro);
            }
        },

        async excluirLivro(livro) {
            if (!confirm(`Excluir “${livro.titulo}” da sua estante?`)) return;
            this.mensagem = "";
            this.erroMensagem = false;
            try {
                const resposta = await fetch(API + "/livros/" + livro.id, {
                    method: "DELETE",
                });
                // O status 204 nao possui corpo: lemos JSON somente em caso de erro.
                if (!resposta.ok) {
                    const erro = await resposta.json();
                    this.mensagem = erro.detail || "Não foi possível excluir o livro.";
                    this.erroMensagem = true;
                    return;
                }
                this.mensagem = `Excluído: ${livro.titulo} (código ${livro.id})`;
                await this.listarLivros();
            } catch (erro) {
                this.mensagem = "Não foi possível acessar a API. Confira se ela está rodando.";
                this.erroMensagem = true;
                console.error("Erro ao excluir livro:", erro);
            }
        },

        editar(livro) {
            this.editando = livro.id;
            this.titulo = livro.titulo;
            this.autor = livro.autor;
            this.ano = livro.ano;
            this.mensagem = "";
            this.erroMensagem = false;
            document.getElementById("titulo").focus();
        },

        cancelarEdicao() {
            this.editando = null;
            this.titulo = "";
            this.autor = "";
            this.ano = "";
            this.mensagem = "";
            this.erroMensagem = false;
        },

        async salvarAlteracao() {
            if (!this.editando) return;
            this.mensagem = "";
            this.erroMensagem = false;
            const alterado = {
                titulo: this.titulo.trim(),
                autor: this.autor.trim(),
                ano: Number(this.ano),
            };
            try {
                const resposta = await fetch(API + "/livros/" + this.editando, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(alterado),
                });
                const livro = await resposta.json();
                if (!resposta.ok) {
                    this.mensagem = livro.detail || "Não foi possível alterar o livro.";
                    this.erroMensagem = true;
                    return;
                }
                this.mensagem = `Alterado: ${livro.titulo} (código ${livro.id})`;
                this.editando = null;
                this.titulo = "";
                this.autor = "";
                this.ano = "";
                await this.listarLivros();
            } catch (erro) {
                this.mensagem = "Não foi possível acessar a API. Confira se ela está rodando.";
                this.erroMensagem = true;
                console.error("Erro ao alterar livro:", erro);
            }
        },
    },
    mounted() {
        this.listarLivros();
    },
});

app.mount("#app");
