from dados.repositorio_livro import RepositorioLivro
from dominio.livro import Livro
from dominio.usuario import Usuario
from dominio.emprestimo import Emprestimo


def carregar_acervo():
    repositorio = RepositorioLivro()
    try:
        return repositorio.listar()
    finally:
        repositorio.fechar()


def salvar_livro(livro):
    repositorio = RepositorioLivro()
    try:
        repositorio.salvar(livro)
    finally:
        repositorio.fechar()


acervo = carregar_acervo()
emprestimos = []
usuario = Usuario("Aluno", 9999)

while True:
    print("=== BIBLIOTECA ===")
    print("1 - CADASTRAR LIVRO")
    print("2 - LISTAR ACERVO")
    print("3 - EMPRÉSTIMO")
    print("4 - DEVOLVER")
    print("0 - SAIR")
    try:
        opcao = int(input("Escolha uma opção: "))
    except ValueError:
        print("Digite o número de uma opção válida.")
        continue

    if opcao == 1:
        titulo = input("Digite o título do livro: ").strip()
        autor = input("Digite o autor do livro: ").strip()
        try:
            ano = int(input("Digite o ano de publicação: "))
            livro = Livro(titulo, autor, ano)
            if any(item.titulo.casefold() == titulo.casefold() and item.autor.casefold() == autor.casefold() for item in acervo):
                print("Esse livro já está cadastrado.")
                continue
            salvar_livro(livro)
            acervo = carregar_acervo()
            print(f"Livro cadastrado: {titulo}, {autor} - {ano}")
        except ValueError as erro:
            print(f"Erro: {erro}")

    elif opcao == 2:
        acervo = carregar_acervo()
        if not acervo:
            print("Acervo vazio, cadastre um livro primeiro!")
        else:
            for livro in acervo:
                print(f"- {livro}")

    elif opcao == 3:
        procurado = input("Título do livro que deseja emprestar: ").strip()
        escolhido = next((livro for livro in acervo if livro.titulo.casefold() == procurado.casefold()), None)
        if escolhido is None:
            print("Livro não está no acervo!")
        else:
            emprestimos.append(Emprestimo(escolhido, usuario, "19/10/2026"))
            print(f"Empréstimo realizado: {emprestimos[-1]}")

    elif opcao == 4:
        procurado = input("Título do livro que deseja devolver: ").strip()
        escolhido = next((item for item in reversed(emprestimos) if item.livro.titulo.casefold() == procurado.casefold() and not item.entregue), None)
        if escolhido is None:
            print("Não há empréstimo em aberto para esse livro.")
        else:
            try:
                escolhido.devolver()
                print(f"Livro {escolhido.livro} devolvido!")
            except ValueError as erro:
                print(f"Não foi possível devolver: {erro}")

    elif opcao == 0:
        print("Até logo...")
        break

    else:
        print("Digite uma opção entre 0 e 4.")
